var app = angular.module('MachineLearning');
app.controller('machineController', function ($scope, $state, $http, $rootScope) {
	//  $scope.modelDetails = [];
	//   $http({

	//         url : 'http://3.209.93.50:5000/dsw/getTrainedModels',
	// 		dataType: 'json',
	//        method: 'GET',
	// 	  headers: { 'Content-Type': 'application/json' }
	//     }).then(function(response) {
	//            //console.log(response);
	// 		   $scope.modelDetails= response.data.models;
	// 		   console.log(response.data.models[0]);
	// 		   console.log($scope.modelDetails);

	// 	});

	/*{
	"stat":true,
	"models":
	[{"_id":"59b6798fd945c8d800fa074b",
	"name":"FirstModel",
	"trainingData":"2500",
	"testingData":"50",
	"predictData":"{v1:172787, v2:-0.73279, v3:-0.05508, v4:2.03503, v5:-0.73859, v6:0.868229, v7:1.058415, v8:0.02433, v9:0.294869, v10:0.5848, v11:-0.97593, v12:-0.15019, v13:0.915802, v14:1.214756, v15:-0.67514, v16:1.164931, v17:-0.71176, v18:-0.02569, v19:-1.22118, v20:-1.54556, v21:0.059616, v22:0.214205, v23:0.924384, v24:0.012463, v25:-1.01623, v26:-0.60662, v27:-0.39526, v28:0.068472, v29:-0.05353, v30:24.79, result:0}",
	"accuracy":"91.5",
	"classifier":"KNN_Classifier",
	"date":"2017-09-11T15:32:55.782Z"}]
	}*/

	$scope.started = false;
	$rootScope.predctTabColor.selectModal = "selectModal";

	$scope.goNext = function () {
		$rootScope.predctTabColor.predictModal = "predictModal"
		$state.go('predict.predictModal');
	}
	$scope.modelDetails = [
		{
			"ModelName": "ABC",
			"CreationDate": "1/12/2014",
			"CreatedBy": "CG",
			"MODEL_ID": 100,
			"NumberOfRows": 88,
			"NumberOfRowsForTraining": 18,
			"NumberOfRowsForTesting": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributesSelected": 80,
			"ClassifierUsed": "Credit Card",
			"Accuracy": "90%"
		},
		{
			"ModelName": "DEF",
			"CreationDate": "7/12/2015",
			"CreatedBy": "CG",
			"MODEL_ID": 101,
			"NumberOfRows": 88,
			"NumberOfRowsForTraining": 18,
			"NumberOfRowsForTesting": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributesSelected": 80,
			"NumberOfRowsForTesting": 88,
			"ClassifierUsed": "Credit Card",
			"Accuracy": "90%"
		},
		{
			"ModelName": "GHI",
			"CreationDate": "8/12/2016",
			"CreatedBy": "CG",
			"MODEL_ID": 102,
			"NumberOfRows": 88,
			"NumberOfRowsForTraining": 18,
			"NumberOfRowsForTesting": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributesSelected": 70,
			"NumberOfRowsForTesting": 88,
			"ClassifierUsed": "Credit Card",
			"Accuracy": "90%"
		},

		{
			"ModelName": "JKL",
			"CreationDate": "22/12/2017",
			"CreatedBy": "CG",
			"MODEL_ID": 103,
			"NumberOfRows": 88,
			"NumberOfRowsForTraining": 18,
			"NumberOfRowsForTesting": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributesSelected": 88,
			"NumberOfRowsForTesting": 88,
			"ClassifierUsed": "Credit Card",
			"Accuracy": "90%"
		},

		{
			"ModelName": "MNO",
			"CreationDate": "12/12/2011",
			"CreatedBy": "CG",
			"MODEL_ID": 104,
			"NumberOfRows": 88,
			"NumberOfRowsForTraining": 18,
			"NumberOfRowsForTesting": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributesSelected": 85,
			"NumberOfRowsForTesting": 88,
			"ClassifierUsed": "Credit Card",
			"Accuracy": "90%"
		},

		{
			"ModelName": "PQR",
			"CreationDate": "9/12/2013",
			"CreatedBy": "CG",
			"MODEL_ID": 105,
			"NumberOfRows": 88,
			"NumberOfRowsForTraining": 18,
			"NumberOfRowsForTesting": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributesSelected": 80,
			"NumberOfRowsForTesting": 88,
			"ClassifierUsed": "Credit Card",
			"Accuracy": "90%"
		},

		{
			"ModelName": "XYZ",
			"CreationDate": "9/12/2013",
			"CreatedBy": "CG",
			"MODEL_ID": 106,
			"NumberOfRows": 88,
			"NumberOfRowsForTraining": 18,
			"NumberOfRowsForTesting": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributesSelected": 80,
			"NumberOfRowsForTesting": 88,
			"ClassifierUsed": "Credit Card",
			"Accuracy": "90%"
		},
		{
			"ModelName": "TCS",
			"CreationDate": "9/12/2013",
			"CreatedBy": "CG",
			"MODEL_ID": 107,
			"NumberOfRows": 88,
			"NumberOfRowsForTraining": 18,
			"NumberOfRowsForTesting": 88,
			"NumberOfAttributes": 88,
			"NumberOfAttributesSelected": 80,
			"NumberOfRowsForTesting": 88,
			"ClassifierUsed": "Credit Card",
			"Accuracy": "90%"
		},


	]
	$scope.nextDisable = true;
	$scope.IsHidden = true;
	$scope.IsHiddenPanel = false;
	/*$scope.ShowHide = function () {
		$scope.IsHidden = false;
	}*/
	$scope.PanelShowHide = function () {

	}

	$scope.applyCss = function (index, classifierName, modelID) {
		$scope.id = index;
		$scope.trainModalDisable = false;
		selectedClassifierName = classifierName;
		$scope.IsHiddenPanel = true;
		$scope.nextDisable = false;
		$scope.IsHidden = false;
		$scope.resArray = [];
		var modelStruct = $scope.modelDetails;
		for (var model in modelStruct) {
			if (modelID === modelStruct[model].MODEL_ID) {
				$scope.resArray.push(modelStruct[model]);
				break;
			}
		}
		console.log("here");
		console.log($scope.resArray);
	};

	$scope.getModelDetails = function (modelID) {



		$scope.IsHiddenPanel = true;
		$scope.nextDisable = false;
		$scope.IsHidden = false;
		$scope.resArray = [];
		var modelStruct = $scope.modelDetails;
		for (var model in modelStruct) {
			if (modelID === modelStruct[model].MODEL_ID) {
				$scope.resArray.push(modelStruct[model]);
				break;
			}
		}
		console.log($scope.resArray);

	};


	/* var onSuccess = function (data, status, headers, config) {
	$scope.data = data;
	};
	
	var onError = function (data, status, headers, config) {
	$scope.error = status;
	};
	var getReq = {
	method: 'GET',
	url: 'http://3.209.93.50:5000/dsw/getTrainedModels'
	};
	$http(getReq).success(onSuccess).error(onError); */

});