var app = angular.module('MachineLearning');
app.controller('DynamicFormController', function ($scope, $log, $state, $rootScope) {

    $scope.keys = [];
    $scope.values = {};
    $scope.key = [];
    $scope.attributes = {};

//     $scope.tabStep = $stateParam.tabStep;
//   $scope.tabValue = $stateParam.tabValue;

    $scope.data = { v1: 172787, v2: -0.73279, v3: -0.05508, v4: 2.03503, v5: -0.73859, v6: 0.868229, v7: 1.058415, v8: 172787, v9: -0.73279, v10: -0.05508, v11: 2.03503, v12: -0.73859, v13: 0.868229, v14: 1.058415, v15: 172787, v16: -0.73279, v16: -0.05508, v17: 2.03503, v18: -0.73859, v19: 0.868229, v20: 1.058415, v21: 172787, v22: -0.73279, v23: -0.05508, v24: 2.03503, v25: -0.73859, v26: 0.868229, v27: 1.058415 }
   

    $scope.goBack = function () {
        $rootScope.predctTabColor.selectModal = "selectModal";
        $rootScope.predctTabColor.predictModal = ""
        $state.go('predict.selectModal');
    }


    
    $scope.display = function () {
        for (var keys in $scope.data) {
            $scope.attributes = {
                keys: keys,
                values: $scope.data[keys]
            }
            $scope.keys.push($scope.attributes);
        }
    }
    $scope.display();

    $scope.flag = false;

    $scope.submitForm = function () {
        $scope.key = [];
        for (var key in $scope.keys) {
            $scope.attributes1 = {
                keys: $scope.keys[key].keys,
                values: $scope.keys[key].values
            }
            $scope.key.push($scope.attributes1);
            $scope.flag = true;
        }
    }

    Highcharts.chart('container1', {
        chart: {
            type: 'bar'
        },
        title: {
            text: 'Prediction Result'
        },
        subtitle: {
            text: null
        },
        xAxis: {
            categories: ['Apple', 'Orange', 'Strawberry', 'Cherry', 'Grape'],
            title: {
                text: null
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Prediction Percentage',
                align: 'high'
            },
            labels: {
                overflow: 'justify'
            }
        },
        tooltip: {
            valueSuffix: '%'
        },
        plotOptions: {
            bar: {
                dataLabels: {
                    enabled: true
                }
            }
        },
        credits: {
            enabled: false
        },
        series: [{
            name: 'Overall Result',
            data: [3, 2, 4, 6, 85]
        }]
    })
});