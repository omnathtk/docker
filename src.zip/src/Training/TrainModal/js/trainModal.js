var app = angular.module('MachineLearning');

app.controller('TrainModalCtrl', ['$scope', '$rootScope', '$state', function ($scope, $rootScope, $state) {


    $scope.goBack = function () {
        $rootScope.tabColor.trainModel = "";
        $state.go('training.selectAttribute');
    }

    $scope.modalData = {

        "Modal": {
            "stat": true,
            "classifiers": [{
                "_id": "59b678f5d945c8d800fa0727",
                "name": "K-Nearest Neighbors Classifier",
                "shortName": "KNN_Classifier",
                "description": "K nearest neighbors is a simple algorithm that stores all available cases and classifies new cases based on a similarity measure (e.g., distance functions). KNNhas been used in statistical estimation and pattern recognition already in the beginning of 1970's as a non-parametric technique.",
                "date": "2017-09-08T15:39:55.782Z"
            },
            {
                "_id": "59b678f5d945c8d800fa0726",
                "name": "Decisicion Tree Classifier",
                "shortName": "DecisionTree_Classifier",
                "description": "A decision tree is a graph that uses a branching method to illustrate every possible outcome of a decision. Programmatically, they can be used to assign monetary/time or other values to possible outcomes so that decisions can be automated.",
                "date": "2017-09-08T15:32:55.782Z"
            }
            ]
        }
    }



    $scope.TrainedModalData = [

        {
            "name": "KNN_Classifier",

            "result": {

                "NoOfSelectedAttributes": 3,
                "NumberOfAttributes": 4,
                "NumberOfTrainingRows": 2,
                "NumberOfRows": 350,
                "NumberOfTestingRows": 266,
                "Accuracy": 58.34586466165413
            }
        },

        {
            "name": "DecisionTree_Classifier",
            "result":
            {
                "NoOfSelectedAttributes": 6,
                "NumberOfAttributes": 10,
                "NumberOfTrainingRows": 5,
                "NumberOfRows": 200,
                "NumberOfTestingRows": 156,
                "Accuracy": 78.34586466165413
            }
        }

    ]





    var selectedClassifierName = "";
    $scope.disabledModel = true;
    $scope.trainModalDisable = true;
    $scope.showAccuracy = true;
    $scope.cancelButton = false;

    $scope.applyCss = function (index, classifierName) {
        $scope.id = index;
        $scope.trainModalDisable = false;
        selectedClassifierName = classifierName;
    };

    $scope.cancelTraining = function () {
        $scope.showAccuracy = true;
        $scope.id = -999;

    }

    $scope.trainedModal = function () {
        $scope.disabledModel = true;
        $scope.trainModalDisable = true;
        var selectedTrainedModal = {};
        $scope.cancelButton = true;
        angular.forEach($scope.TrainedModalData, function (value, key) {
            if (value.name === selectedClassifierName) {
                selectedTrainedModal = value;
            }
        });

        $scope.selectedClassfierResult = selectedTrainedModal.result;
        $scope.showAccuracy = false;

    }

}]);