var app = angular.module('MachineLearning');
app.controller('TrainingTabController', function ($scope, $window, $rootScope, $state) {


  function onload() {
    $state.go('training.uploadCSV');

  } onload();




  $rootScope.tabColor = { "uploadData": "", "selectAttribute": "", "trainModel": "" };

  $scope.changeTab = function (value) {

    if (value === 'uploadData') {

      $rootScope.tabColor.uploadData = "uploadDataSet";
      $rootScope.tabColor.selectAttribute = "";
      $rootScope.tabColor.trainModel = "";

    }

    else if (value === 'selectAtrribute') {

      $rootScope.tabColor.uploadData = "uploadDataSet";
      $rootScope.tabColor.selectAttribute = "attributeSelection";
      $rootScope.tabColor.trainModel = "";

    }

    else if (value === 'trainModel') {

      $rootScope.tabColor.uploadData = "uploadDataSet";
      $rootScope.tabColor.selectAttribute = "attributeSelection";
      $rootScope.tabColor.trainModel = "trainModel";

    }

  }

});